from imageai.Detection import VideoObjectDetection
def vai():
    detector = VideoObjectDetection()
    model_path = "yolov3 .pt"
    detector.setModelTypeAsYOLOv3()
    detector.setModelPath(model_path)
    detector.loadModel()

    detector.detectObjectsFromVideo(
        input_file_path="vd..mp4",
        output_file_path="output_video",
        frames_per_second=20,
        minimum_percentage_probability=30,return_detected_frame=True, log_progress=True)
    sonuc = "videofotoai/fotoai/output_video.mp4"          
    return sonuc