from imageai.Detection import VideoObjectDetection
import discord
from discord.ext import commands
import os
import random
import webbrowser as web
import time
import requests
from pytube import YouTube
import yt_dlp
import videoai

intents = discord.Intents.default()

# Mesajları okuma ayrıcalığını etkinleştirelim

intents.message_content = True

# istemci (client) değişkeniyle bir bot oluşturalım ve ayrıcalıkları ona aktaralım

client = discord.Client(intents=intents)
       

client = commands.Bot(intents=intents,command_prefix="!")

client_token = 'MTE3NTQwNjE3MzI5MDIzODAwMg.Gw5eAX.FKa1LVvdMqziltt1kxpgPMmNJt1GvuJ_acqVuU'


def video_indir(video_url, kayit_yolu='./'):
    try:
        ydl_opts = {
            'format': 'best',
            'outtmpl': f'{kayit_yolu}/%(title)s.%(ext)s',
        }
        
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info_dict = ydl.extract_info(video_url, download=True)

        print("Video başarıyla indirildi.")
        return info_dict
    except Exception as e:
        print(f"Bir hata oluştu: {e}")
        return None

def video_isim_degistir(video_adi, yeni_isim):
    try:
        yeni_video_adi = os.path.join(os.path.dirname(video_adi), f"{yeni_isim}.{os.path.splitext(video_adi)[1]}")
        os.rename(video_adi, yeni_video_adi)
        
        print(f"Video ismi başarıyla değiştirildi. Yeni isim: {yeni_video_adi}")
        return yeni_video_adi
    except FileNotFoundError:
        print("Belirtilen video bulunamadı.")
        return None
    except Exception as e:
        print(f"Bir hata oluştu: {e}")
        return None

# Kullanım örneği
@client.command()
async def vip(ctx, video_url, yeni_isim="vd"):
    kayit_yolu = ''
    info_dict = video_indir(video_url, kayit_yolu)

    if info_dict:
        video_adi = os.path.join(kayit_yolu, f"{info_dict['title']}.{info_dict['ext']}")
        yeni_video_adi = video_isim_degistir(video_adi, yeni_isim)

        if yeni_video_adi:
            # Videoyu Discord'a yükleyin
            video_file = discord.File(yeni_video_adi)
            await ctx.send(file=video_file)
    result = videoai.vai()
    await ctx.send(result)
    f = open("output_video.mp4", "rb")
    sonuc = discord.File(f)
    await ctx.send(file=sonuc)


client.run("")  # "TOKEN" kısmını kendi bot tokeninizle değiştirin
